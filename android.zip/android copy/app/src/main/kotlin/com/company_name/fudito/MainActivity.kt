package com.company_name.fudito

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
